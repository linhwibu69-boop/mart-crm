import logging, os
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.exceptions import RequestValidationError
from sqlalchemy.exc import IntegrityError, OperationalError
from sqlalchemy import text
from .database import ROOT, Base, engine
from . import models
from .controllers import auth, catalog, purchases, reports

@asynccontextmanager
async def lifespan(app):
    Base.metadata.create_all(engine)
    yield

app=FastAPI(title='Mart CRM API',version='1.0.0',description='Ứng dụng quản lí khách mua hàng tại siêu thị. Dữ liệu trong bản bàn giao là dữ liệu kiểm thử.',docs_url='/api/docs',openapi_url='/api/openapi.json',lifespan=lifespan)

@app.middleware('http')
async def security_headers(request:Request, call_next):
    length=request.headers.get('content-length','0')
    if length.isdigit() and int(length)>100_000: return JSONResponse({'message':'Yêu cầu quá lớn'},status_code=413)
    response=await call_next(request)
    response.headers['X-Content-Type-Options']='nosniff'
    response.headers['X-Frame-Options']='DENY'
    response.headers['Referrer-Policy']='same-origin'
    if not request.url.path.startswith('/api/docs'):
        response.headers['Content-Security-Policy']="default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; form-action 'self'"
    if request.url.path.startswith('/api/'): response.headers['Cache-Control']='no-store'
    return response

@app.exception_handler(HTTPException)
async def http_error(_,exc): return JSONResponse({'message':exc.detail},status_code=exc.status_code)

@app.exception_handler(RequestValidationError)
async def validation_error(_,exc):
    errors=[{'field':'.'.join(map(str,e['loc'][1:])),'message':e['msg']} for e in exc.errors()]
    return JSONResponse({'message':'Dữ liệu không hợp lệ','errors':errors},status_code=422)

@app.exception_handler(IntegrityError)
async def constraint_error(_,exc): return JSONResponse({'message':'Dữ liệu vi phạm ràng buộc toàn vẹn'},status_code=409)

@app.exception_handler(OperationalError)
async def busy_error(_,exc):
    logging.exception('Database operation failed')
    return JSONResponse({'message':'Cơ sở dữ liệu tạm bận. Vui lòng thử lại'},status_code=503)

@app.exception_handler(Exception)
async def internal_error(_,exc):
    logging.exception('Unhandled server error')
    return JSONResponse({'message':'Có lỗi máy chủ. Vui lòng thử lại'},status_code=500)

for router in [auth.router,catalog.router,purchases.router,reports.router]: app.include_router(router)

@app.get('/api/health',tags=['Hệ thống'])
def health():
    with engine.connect() as c: c.execute(text('SELECT 1'))
    return {'status':'ok','database':'SQLite','orm':'SQLAlchemy'}

app.mount('/static',StaticFiles(directory=ROOT/'static'),name='static')

@app.get('/',include_in_schema=False)
def index(): return FileResponse(ROOT/'static'/'index.html')
