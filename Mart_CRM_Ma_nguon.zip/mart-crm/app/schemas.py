import re
from pydantic import BaseModel, ConfigDict, Field, field_validator

class StrictDTO(BaseModel):
    model_config = ConfigDict(extra='forbid', str_strip_whitespace=True)

class LoginDTO(StrictDTO):
    username: str = Field(min_length=3, max_length=40)
    password: str = Field(min_length=8, max_length=128)

class CustomerDTO(StrictDTO):
    name: str = Field(min_length=2, max_length=100)
    phone: str
    email: str | None = Field(default=None, max_length=120)
    address: str = Field(default='', max_length=200)
    consent: bool = False
    active: bool = True

    @field_validator('phone')
    @classmethod
    def phone_valid(cls, v):
        if not re.fullmatch(r'0[35789]\d{8}', v):
            raise ValueError('Số điện thoại gồm 10 số, bắt đầu bằng 03, 05, 07, 08 hoặc 09')
        return v

    @field_validator('email')
    @classmethod
    def email_valid(cls, v):
        if not v: return None
        if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+', v): raise ValueError('Email không hợp lệ')
        return v.lower()

class ProductDTO(StrictDTO):
    sku: str = Field(min_length=2, max_length=30, pattern=r'^[A-Z0-9-]+$')
    name: str = Field(min_length=2, max_length=100)
    category: str = Field(min_length=2, max_length=50)
    price: int = Field(gt=0, le=100_000_000, strict=True)
    stock: int = Field(ge=0, le=1_000_000, strict=True)
    active: bool = True

class ItemDTO(StrictDTO):
    product_id: int = Field(gt=0, strict=True)
    quantity: int = Field(gt=0, le=10000, strict=True)

class PurchaseDTO(StrictDTO):
    customer_id: int = Field(gt=0, strict=True)
    items: list[ItemDTO] = Field(min_length=1, max_length=50)
    redeem_points: int = Field(default=0, ge=0, le=1_000_000, strict=True)
    request_key: str = Field(min_length=8, max_length=80, pattern=r'^[a-zA-Z0-9-]+$')

    @field_validator('items')
    @classmethod
    def distinct_products(cls, items):
        if len({i.product_id for i in items}) != len(items): raise ValueError('Sản phẩm không được lặp trong giỏ')
        return items

class CancelDTO(StrictDTO):
    reason: str = Field(min_length=5, max_length=200)
