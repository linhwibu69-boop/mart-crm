import os, secrets, time
from fastapi import APIRouter, Depends, Request, Response, HTTPException
from sqlalchemy import select
from ..database import get_db
from ..models import User, AuthSession
from ..schemas import LoginDTO
from ..security import verify_password, token_hash, current_user, limit_login

router=APIRouter(prefix='/api/auth',tags=['Xác thực'])

@router.post('/login')
def login(dto: LoginDTO, request: Request, response: Response, db=Depends(get_db)):
    limit_login(request.client.host if request.client else 'local')
    user=db.scalar(select(User).where(User.username==dto.username))
    if not user or not verify_password(dto.password,user.password_hash):
        raise HTTPException(401,'Tên đăng nhập hoặc mật khẩu không đúng')
    token=secrets.token_urlsafe(32); csrf=secrets.token_hex(32)
    db.add(AuthSession(user_id=user.id,token_hash=token_hash(token),csrf=csrf,expires=int(time.time())+28800));db.commit()
    response.set_cookie('mart_session',token,httponly=True,samesite='strict',secure=os.getenv('MART_SECURE_COOKIE')=='1',max_age=28800,path='/')
    return dict(id=user.id,username=user.username,role=user.role,csrf=csrf)

@router.get('/me')
def me(request: Request, user=Depends(current_user)):
    return dict(id=user.id,username=user.username,role=user.role,csrf=request.state.session.csrf)

@router.post('/logout',status_code=204)
def logout(request: Request, response: Response, user=Depends(current_user), db=Depends(get_db)):
    db.delete(request.state.session);db.commit();response.delete_cookie('mart_session',path='/')
