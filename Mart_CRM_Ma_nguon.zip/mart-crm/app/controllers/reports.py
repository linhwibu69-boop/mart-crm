import csv, io
from fastapi import APIRouter, Depends
from fastapi.responses import Response
from sqlalchemy import select, func
from ..database import get_db
from ..models import Customer, Product, Purchase, AuditLog, User
from ..security import current_user, admin_user
from ..repositories.catalog import CatalogRepository
from ..services.catalog import customer_json

router=APIRouter(prefix='/api',tags=['Báo cáo'])

@router.get('/reports/summary')
def summary(user=Depends(current_user),db=Depends(get_db)):
    paid=db.scalars(select(Purchase).where(Purchase.status=='PAID')).all()
    repo=CatalogRepository(db); customers=[customer_json(x,repo) for x in repo.customers()]
    monthly={}
    for p in paid:
        month=p.created_at[:7];monthly[month]=monthly.get(month,0)+p.total
    return dict(customers=len(customers),active_customers=sum(c['active'] for c in customers),
                orders=len(paid),revenue=sum(p.total for p in paid),points=sum(c['points'] for c in customers),
                cancelled=db.scalar(select(func.count(Purchase.id)).where(Purchase.status=='CANCELLED')),
                low_stock=db.scalar(select(func.count(Product.id)).where(Product.stock<10,Product.active==True)),
                tiers={t:sum(c['tier']==t for c in customers) for t in ['Thành viên','Bạc','Vàng']},
                monthly=[dict(month=m,revenue=v) for m,v in sorted(monthly.items())],
                top_customers=sorted(customers,key=lambda x:x['total_spent'],reverse=True)[:5])

@router.get('/audit')
def audit(user=Depends(admin_user),db=Depends(get_db)):
    rows=db.execute(select(AuditLog,User.username).join(User,User.id==AuditLog.user_id).order_by(AuditLog.id.desc()).limit(100)).all()
    return [dict(id=a.id,username=u,action=a.action,entity=a.entity,entity_id=a.entity_id,created_at=a.created_at) for a,u in rows]

@router.get('/reports/customers.csv')
def export(user=Depends(admin_user),db=Depends(get_db)):
    buf=io.StringIO(); w=csv.writer(buf);w.writerow(['Mã','Họ tên','Điện thoại','Email','Hạng','Điểm','Chi tiêu'])
    repo=CatalogRepository(db)
    def safe(v):
        text=str(v or '')
        return "'"+text if text.startswith(('=','+','-','@','\t','\r','\n')) else text
    for c in repo.customers():
        d=customer_json(c,repo);w.writerow([safe(d[k]) for k in ['id','name','phone','email','tier','points','total_spent']])
    return Response(('\ufeff'+buf.getvalue()).encode('utf-8'),media_type='text/csv; charset=utf-8',headers={'Content-Disposition':'attachment; filename="khach-hang.csv"'})
