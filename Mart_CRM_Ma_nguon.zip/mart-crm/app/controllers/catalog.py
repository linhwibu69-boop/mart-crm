from fastapi import APIRouter, Depends, Query, Response
from sqlalchemy import select
from ..database import get_db
from ..models import Customer, Product, Purchase, LoyaltyEntry
from ..schemas import CustomerDTO, ProductDTO
from ..security import current_user, admin_user
from ..repositories.catalog import CatalogRepository
from ..services.catalog import CatalogService, customer_json, product_json
from ..services.purchases import purchase_json

router=APIRouter(prefix='/api',tags=['Khách hàng và sản phẩm'])

@router.get('/customers')
def customers(search: str=Query('',max_length=100),active: bool|None=None,user=Depends(current_user),db=Depends(get_db)):
    repo=CatalogRepository(db)
    return [customer_json(x,repo) for x in repo.customers(search,active)]

@router.get('/customers/{entity_id}')
def customer(entity_id:int,user=Depends(current_user),db=Depends(get_db)):
    repo=CatalogRepository(db);row=repo.get(Customer,entity_id)
    result=customer_json(row,repo)
    result['purchases']=[purchase_json(x) for x in db.scalars(select(Purchase).where(Purchase.customer_id==entity_id).order_by(Purchase.id.desc()))]
    result['ledger']=[dict(id=x.id,purchase_id=x.purchase_id,delta=x.delta,kind=x.kind,created_at=x.created_at) for x in db.scalars(select(LoyaltyEntry).where(LoyaltyEntry.customer_id==entity_id).order_by(LoyaltyEntry.id.desc()))]
    return result

@router.post('/customers',status_code=201)
def create_customer(dto:CustomerDTO,user=Depends(current_user),db=Depends(get_db)):
    return CatalogService(db).save(Customer,dto,user)

@router.put('/customers/{entity_id}')
def update_customer(entity_id:int,dto:CustomerDTO,user=Depends(current_user),db=Depends(get_db)):
    return CatalogService(db).save(Customer,dto,user,entity_id)

@router.delete('/customers/{entity_id}',status_code=204)
def delete_customer(entity_id:int,user=Depends(admin_user),db=Depends(get_db)):
    CatalogService(db).remove(Customer,entity_id,user)

@router.get('/products')
def products(user=Depends(current_user),db=Depends(get_db)):
    return [product_json(x) for x in CatalogRepository(db).products()]

@router.get('/products/{entity_id}')
def product(entity_id:int,user=Depends(current_user),db=Depends(get_db)):
    return product_json(CatalogRepository(db).get(Product,entity_id))

@router.post('/products',status_code=201)
def create_product(dto:ProductDTO,user=Depends(admin_user),db=Depends(get_db)):
    return CatalogService(db).save(Product,dto,user)

@router.put('/products/{entity_id}')
def update_product(entity_id:int,dto:ProductDTO,user=Depends(admin_user),db=Depends(get_db)):
    return CatalogService(db).save(Product,dto,user,entity_id)

@router.delete('/products/{entity_id}',status_code=204)
def delete_product(entity_id:int,user=Depends(admin_user),db=Depends(get_db)):
    CatalogService(db).remove(Product,entity_id,user)
