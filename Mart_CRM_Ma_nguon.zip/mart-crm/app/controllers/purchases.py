from fastapi import APIRouter, Depends
from sqlalchemy import select
from ..database import get_db
from ..models import Purchase
from ..schemas import PurchaseDTO, CancelDTO
from ..security import current_user, admin_user
from ..repositories.catalog import CatalogRepository
from ..services.purchases import PurchaseService, purchase_json

router=APIRouter(prefix='/api/purchases',tags=['Mua hàng'])

@router.get('')
def purchases(user=Depends(current_user),db=Depends(get_db)):
    return [purchase_json(x) for x in db.scalars(select(Purchase).order_by(Purchase.id.desc()))]

@router.get('/{entity_id}')
def purchase(entity_id:int,user=Depends(current_user),db=Depends(get_db)):
    return purchase_json(CatalogRepository(db).get(Purchase,entity_id))

@router.post('',status_code=201)
def create(dto:PurchaseDTO,user=Depends(current_user),db=Depends(get_db)):
    return PurchaseService(db).create(dto,user)

@router.post('/{entity_id}/cancel')
def cancel(entity_id:int,dto:CancelDTO,user=Depends(admin_user),db=Depends(get_db)):
    return PurchaseService(db).cancel(entity_id,dto,user)
