from fastapi import HTTPException
from sqlalchemy import select, func
from ..models import Customer, Product, Purchase

class CatalogRepository:
    def __init__(self, db): self.db = db
    def get(self, model, entity_id):
        row = self.db.get(model, entity_id)
        if not row: raise HTTPException(404, 'Không tìm thấy dữ liệu')
        return row
    def customer_spent(self, customer_id):
        return self.db.scalar(select(func.coalesce(func.sum(Purchase.total),0)).where(Purchase.customer_id==customer_id, Purchase.status=='PAID'))
    def customers(self, search='', active=None):
        query = select(Customer).order_by(Customer.id.desc())
        if search:
            s=search.replace('\\','\\\\').replace('%','\\%').replace('_','\\_')
            query=query.where(Customer.name.ilike('%'+s+'%',escape='\\') | Customer.phone.contains(s,escape='\\'))
        if active is not None: query=query.where(Customer.active==active)
        return self.db.scalars(query).all()
    def products(self): return self.db.scalars(select(Product).order_by(Product.id)).all()
