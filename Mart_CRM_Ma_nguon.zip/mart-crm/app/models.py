from datetime import datetime, timezone
from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, CheckConstraint, UniqueConstraint
from sqlalchemy.orm import relationship
from .database import Base

def now():
    return datetime.now(timezone.utc).isoformat(timespec='seconds')

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    username = Column(String(40), unique=True, nullable=False)
    password_hash = Column(String(256), nullable=False)
    role = Column(String(16), nullable=False)
    __table_args__ = (CheckConstraint("role IN ('admin','cashier')"),)
    sessions = relationship('AuthSession', back_populates='user')

class AuthSession(Base):
    __tablename__ = 'auth_sessions'
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    token_hash = Column(String(64), unique=True, nullable=False)
    csrf = Column(String(64), nullable=False)
    expires = Column(Integer, nullable=False)
    user = relationship('User', back_populates='sessions')

class Customer(Base):
    __tablename__ = 'customers'
    id = Column(Integer, primary_key=True)
    name = Column(String(100), nullable=False)
    phone = Column(String(10), unique=True, nullable=False)
    email = Column(String(120), nullable=True)
    address = Column(String(200), nullable=False, default='')
    consent = Column(Boolean, nullable=False, default=False)
    active = Column(Boolean, nullable=False, default=True)
    points = Column(Integer, nullable=False, default=0)
    created_at = Column(String, nullable=False, default=now)
    purchases = relationship('Purchase', back_populates='customer')
    ledger = relationship('LoyaltyEntry', back_populates='customer')
    __table_args__ = (CheckConstraint('points >= 0'),)

class Product(Base):
    __tablename__ = 'products'
    id = Column(Integer, primary_key=True)
    sku = Column(String(30), unique=True, nullable=False)
    name = Column(String(100), nullable=False)
    category = Column(String(50), nullable=False)
    price = Column(Integer, nullable=False)
    stock = Column(Integer, nullable=False, default=0)
    active = Column(Boolean, nullable=False, default=True)
    __table_args__ = (CheckConstraint('price > 0'), CheckConstraint('stock >= 0'))

class Purchase(Base):
    __tablename__ = 'purchases'
    id = Column(Integer, primary_key=True)
    customer_id = Column(Integer, ForeignKey('customers.id', ondelete='RESTRICT'), nullable=False)
    user_id = Column(Integer, ForeignKey('users.id', ondelete='RESTRICT'), nullable=False)
    request_key = Column(String(80), unique=True, nullable=False)
    request_hash = Column(String(64), nullable=False)
    gross = Column(Integer, nullable=False)
    redeemed = Column(Integer, nullable=False)
    earned = Column(Integer, nullable=False)
    total = Column(Integer, nullable=False)
    status = Column(String(12), nullable=False, default='PAID')
    cancel_reason = Column(String(200), nullable=True)
    created_at = Column(String, nullable=False, default=now)
    customer = relationship('Customer', back_populates='purchases')
    items = relationship('PurchaseItem', back_populates='purchase', cascade='all, delete-orphan')
    __table_args__ = (CheckConstraint("status IN ('PAID','CANCELLED')"), CheckConstraint('total >= 0'))

class PurchaseItem(Base):
    __tablename__ = 'purchase_items'
    id = Column(Integer, primary_key=True)
    purchase_id = Column(Integer, ForeignKey('purchases.id', ondelete='CASCADE'), nullable=False)
    product_id = Column(Integer, ForeignKey('products.id', ondelete='RESTRICT'), nullable=False)
    product_name = Column(String(100), nullable=False)
    quantity = Column(Integer, nullable=False)
    unit_price = Column(Integer, nullable=False)
    purchase = relationship('Purchase', back_populates='items')
    __table_args__ = (CheckConstraint('quantity > 0'), CheckConstraint('unit_price > 0'), UniqueConstraint('purchase_id','product_id'))

class LoyaltyEntry(Base):
    __tablename__ = 'loyalty_entries'
    id = Column(Integer, primary_key=True)
    customer_id = Column(Integer, ForeignKey('customers.id', ondelete='RESTRICT'), nullable=False)
    purchase_id = Column(Integer, ForeignKey('purchases.id', ondelete='RESTRICT'), nullable=False)
    delta = Column(Integer, nullable=False)
    kind = Column(String(20), nullable=False)
    created_at = Column(String, nullable=False, default=now)
    customer = relationship('Customer', back_populates='ledger')

class AuditLog(Base):
    __tablename__ = 'audit_logs'
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey('users.id', ondelete='RESTRICT'), nullable=False)
    action = Column(String(40), nullable=False)
    entity = Column(String(30), nullable=False)
    entity_id = Column(Integer, nullable=False)
    created_at = Column(String, nullable=False, default=now)
