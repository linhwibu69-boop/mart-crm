from fastapi import HTTPException
from sqlalchemy import select, text
from sqlalchemy.exc import IntegrityError
from ..models import Customer, Product, Purchase, PurchaseItem, AuditLog
from ..repositories.catalog import CatalogRepository

def begin_write(db):
    # End the read-only authentication transaction, then reserve the SQLite writer.
    db.rollback()
    db.execute(text('BEGIN IMMEDIATE'))

def audit(db, user_id, action, entity, entity_id):
    db.add(AuditLog(user_id=user_id, action=action, entity=entity, entity_id=entity_id))

def tier(spent): return 'Vàng' if spent >= 5_000_000 else 'Bạc' if spent >= 2_000_000 else 'Thành viên'

def customer_json(row, repo):
    spent=repo.customer_spent(row.id)
    return dict(id=row.id,name=row.name,phone=row.phone,email=row.email,address=row.address,consent=row.consent,
                active=row.active,points=row.points,total_spent=spent,tier=tier(spent),created_at=row.created_at)

def product_json(row):
    return {k:getattr(row,k) for k in ['id','sku','name','category','price','stock','active']}

class CatalogService:
    def __init__(self, db): self.db=db; self.repo=CatalogRepository(db)
    def save(self, model, dto, actor, entity_id=None):
        actor_id=actor.id; begin_write(self.db)
        try:
            row=self.repo.get(model,entity_id) if entity_id else model()
            for k,v in dto.model_dump().items(): setattr(row,k,v)
            self.db.add(row); self.db.flush()
            audit(self.db,actor_id,'UPDATE' if entity_id else 'CREATE',model.__tablename__,row.id)
            self.db.commit()
            return customer_json(row,self.repo) if model==Customer else product_json(row)
        except IntegrityError:
            self.db.rollback(); raise HTTPException(409,'Số điện thoại hoặc mã sản phẩm đã tồn tại')
    def remove(self, model, entity_id, actor):
        actor_id=actor.id; begin_write(self.db)
        row=self.repo.get(model,entity_id)
        used=self.db.scalar(select(Purchase.id).where(Purchase.customer_id==entity_id).limit(1)) if model==Customer else self.db.scalar(select(PurchaseItem.id).where(PurchaseItem.product_id==entity_id).limit(1))
        if used: raise HTTPException(409,'Đã có lịch sử mua hàng. Hãy ngừng hoạt động thay vì xóa')
        audit(self.db,actor_id,'DELETE',model.__tablename__,row.id)
        self.db.delete(row); self.db.commit()
