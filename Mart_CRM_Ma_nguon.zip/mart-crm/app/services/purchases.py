import hashlib, json
from fastapi import HTTPException
from sqlalchemy import select
from ..models import Customer, Product, Purchase, PurchaseItem, LoyaltyEntry
from ..repositories.catalog import CatalogRepository
from .catalog import begin_write, audit

def calculate(gross, redeem, balance):
    if redeem > balance: raise HTTPException(409, 'Không đủ điểm để đổi')
    discount=redeem*1000
    if discount*5 > gross: raise HTTPException(409, 'Điểm đổi tối đa bằng 20% giá trị hàng')
    total=gross-discount
    return total, total//10000

def purchase_json(row):
    return dict(id=row.id,customer_id=row.customer_id,customer_name=row.customer.name,user_id=row.user_id,
                gross=row.gross,redeemed=row.redeemed,discount=row.redeemed*1000,earned=row.earned,total=row.total,
                status=row.status,cancel_reason=row.cancel_reason,created_at=row.created_at,
                items=[dict(product_id=i.product_id,name=i.product_name,quantity=i.quantity,unit_price=i.unit_price,
                            subtotal=i.quantity*i.unit_price) for i in row.items])

class PurchaseService:
    def __init__(self, db): self.db=db; self.repo=CatalogRepository(db)
    def create(self, dto, actor):
        actor_id=actor.id; begin_write(self.db)
        digest=hashlib.sha256(json.dumps(dto.model_dump(exclude={'request_key'}),sort_keys=True).encode()).hexdigest()
        existing=self.db.scalar(select(Purchase).where(Purchase.request_key==dto.request_key))
        if existing:
            if existing.user_id != actor_id or existing.request_hash != digest:
                raise HTTPException(409, 'Mã yêu cầu đã dùng cho nội dung khác')
            return purchase_json(existing)
        customer=self.repo.get(Customer,dto.customer_id)
        if not customer.active: raise HTTPException(409,'Khách hàng đã ngừng hoạt động')
        products=[]; gross=0
        for item in dto.items:
            product=self.repo.get(Product,item.product_id)
            if not product.active: raise HTTPException(409,'Sản phẩm đã ngừng bán')
            if item.quantity > product.stock: raise HTTPException(409,'Không đủ tồn kho: '+product.name)
            products.append((product,item.quantity)); gross+=product.price*item.quantity
        total, earned=calculate(gross,dto.redeem_points,customer.points)
        order=Purchase(customer_id=customer.id,user_id=actor_id,request_key=dto.request_key,request_hash=digest,
                       gross=gross,redeemed=dto.redeem_points,earned=earned,total=total)
        self.db.add(order); self.db.flush()
        for product, quantity in products:
            product.stock-=quantity
            self.db.add(PurchaseItem(purchase_id=order.id,product_id=product.id,product_name=product.name,quantity=quantity,unit_price=product.price))
        if dto.redeem_points:
            self.db.add(LoyaltyEntry(customer_id=customer.id,purchase_id=order.id,delta=-dto.redeem_points,kind='REDEEM'))
        self.db.add(LoyaltyEntry(customer_id=customer.id,purchase_id=order.id,delta=earned,kind='EARN'))
        customer.points+=earned-dto.redeem_points
        audit(self.db,actor_id,'CHECKOUT','purchases',order.id)
        self.db.commit()
        return purchase_json(order)
    def cancel(self, entity_id, dto, actor):
        actor_id=actor.id; begin_write(self.db)
        order=self.repo.get(Purchase,entity_id)
        if order.status=='CANCELLED': raise HTTPException(409,'Hóa đơn đã hủy')
        customer=order.customer
        if customer.points+order.redeemed-order.earned < 0:
            raise HTTPException(409,'Điểm từ hóa đơn đã được sử dụng. Cần xử lý hóa đơn liên quan trước')
        for item in order.items: self.repo.get(Product,item.product_id).stock+=item.quantity
        customer.points+=order.redeemed-order.earned
        self.db.add(LoyaltyEntry(customer_id=customer.id,purchase_id=order.id,delta=order.redeemed-order.earned,kind='CANCEL'))
        order.status='CANCELLED'; order.cancel_reason=dto.reason
        audit(self.db,actor_id,'CANCEL','purchases',order.id)
        self.db.commit()
        return purchase_json(order)
