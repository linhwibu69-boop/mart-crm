import hashlib, secrets, time, os
from collections import defaultdict
from fastapi import Depends, HTTPException, Request
from sqlalchemy import select
from .database import get_db
from .models import AuthSession

def hash_password(password):
    salt = secrets.token_hex(16)
    digest = hashlib.scrypt(password.encode(), salt=salt.encode(), n=16384, r=8, p=1).hex()
    return salt + ':' + digest

def verify_password(password, encoded):
    salt, digest = encoded.split(':')
    computed = hashlib.scrypt(password.encode(), salt=salt.encode(), n=16384, r=8, p=1).hex()
    return secrets.compare_digest(computed, digest)

def token_hash(value): return hashlib.sha256(value.encode()).hexdigest()

def current_user(request: Request, db=Depends(get_db)):
    raw = request.cookies.get('mart_session', '')
    session = db.scalar(select(AuthSession).where(AuthSession.token_hash == token_hash(raw), AuthSession.expires > int(time.time())))
    if not session: raise HTTPException(401, 'Vui lòng đăng nhập')
    if request.method not in ('GET', 'HEAD', 'OPTIONS'):
        csrf = request.headers.get('X-CSRF-Token', '')
        if not secrets.compare_digest(csrf, session.csrf): raise HTTPException(403, 'CSRF token không hợp lệ')
    request.state.session = session
    return session.user

def admin_user(user=Depends(current_user)):
    if user.role != 'admin': raise HTTPException(403, 'Chỉ quản trị viên được thực hiện thao tác này')
    return user

attempts = defaultdict(list)
def limit_login(key):
    t=time.time(); attempts[key] = [x for x in attempts[key] if t-x < 60]
    if len(attempts[key]) >= 10: raise HTTPException(429, 'Quá nhiều lần đăng nhập. Thử lại sau 60 giây')
    attempts[key].append(t)
