SQLite is generated locally by seed.py on first run.
