import os, tempfile, unittest, uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
TEMP=tempfile.TemporaryDirectory(prefix='mart-test-')
os.environ['MART_DB']=str(Path(TEMP.name)/'tests.sqlite3')
from fastapi.testclient import TestClient
from fastapi import HTTPException
from pydantic import ValidationError
from sqlalchemy import select, func, text
from sqlalchemy.exc import IntegrityError
from app.main import app
from app.database import Base, engine, SessionLocal
from app.models import User, Customer, Product, Purchase, LoyaltyEntry
from app.schemas import CustomerDTO, ProductDTO, PurchaseDTO
from app.security import hash_password, verify_password, attempts
from app.services.catalog import tier
from app.services.purchases import calculate

class UnitTests(unittest.TestCase):
    def test_01_tier_boundaries(self):
        self.assertEqual([tier(x) for x in [0,1999999,2000000,4999999,5000000]],['Thành viên','Thành viên','Bạc','Bạc','Vàng'])
    def test_02_round_points_down(self): self.assertEqual(calculate(99999,0,0),(99999,9))
    def test_03_redeem_exact_20_percent(self): self.assertEqual(calculate(100000,20,20),(80000,8))
    def test_04_redeem_over_limit(self):
        with self.assertRaises(HTTPException) as e:calculate(100000,21,100)
        self.assertEqual(e.exception.status_code,409)
    def test_05_insufficient_points(self):
        with self.assertRaises(HTTPException):calculate(100000,5,4)
    def test_06_password_salt_and_verify(self):
        a=hash_password('Unit!Password123');b=hash_password('Unit!Password123')
        self.assertNotEqual(a,b);self.assertTrue(verify_password('Unit!Password123',a));self.assertFalse(verify_password('wrong',a))
    def test_07_phone_and_email_validation(self):
        for phone in ['123','09000000001','abc','0100000000']:
            with self.assertRaises(ValidationError):CustomerDTO(name='Khách thử',phone=phone)
        self.assertEqual(CustomerDTO(name='Khách thử',phone='0900000001',email='A@EXAMPLE.COM').email,'a@example.com')
    def test_08_no_client_price_or_points(self):
        with self.assertRaises(ValidationError):CustomerDTO(name='Khách thử',phone='0900000001',points=999)
        with self.assertRaises(ValidationError):ProductDTO(sku='XX',name='Thử',category='Thử',price=1.5,stock=1)
    def test_09_duplicate_cart_lines(self):
        with self.assertRaises(ValidationError):PurchaseDTO(customer_id=1,items=[{'product_id':1,'quantity':1}]*2,request_key='test-key-123')

class APITests(unittest.TestCase):
    def setUp(self):
        attempts.clear();Base.metadata.drop_all(engine);Base.metadata.create_all(engine)
        with SessionLocal() as db:
            db.add_all([User(username='admin',password_hash=hash_password('Admin!Test2026'),role='admin'),User(username='cashier',password_hash=hash_password('Cashier!Test2026'),role='cashier'),Customer(name='Khách kiểm thử',phone='0900000001'),Product(sku='TEST-01',name='Hàng kiểm thử',category='Kiểm thử',price=100000,stock=10)])
            db.commit()
        self.client=TestClient(app);self.client.__enter__()
        r=self.client.post('/api/auth/login',json={'username':'admin','password':'Admin!Test2026'})
        self.assertEqual(r.status_code,200);self.headers={'X-CSRF-Token':r.json()['csrf']}
    def tearDown(self):self.client.__exit__(None,None,None)
    def req(self,method,url,body=None):return self.client.request(method,'/api'+url,json=body,headers=self.headers)
    def order(self,qty=1,redeem=0,key=None,items=None):
        return self.req('POST','/purchases',{'customer_id':1,'items':items or [{'product_id':1,'quantity':qty}],'redeem_points':redeem,'request_key':key or str(uuid.uuid4())})
    def cashier(self):
        r=self.client.post('/api/auth/login',json={'username':'cashier','password':'Cashier!Test2026'});self.headers={'X-CSRF-Token':r.json()['csrf']}
    def test_10_health_and_relational_database(self):
        self.assertEqual(self.req('GET','/health').json()['orm'],'SQLAlchemy')
        with engine.connect() as c:self.assertEqual(c.execute(text('PRAGMA foreign_keys')).scalar(),1)
    def test_11_login_wrong_password(self):self.assertEqual(self.client.post('/api/auth/login',json={'username':'admin','password':'Incorrect123'}).status_code,401)
    def test_12_requires_session(self):
        with TestClient(app) as c:self.assertEqual(c.get('/api/customers').status_code,401)
    def test_13_csrf_required(self):self.assertEqual(self.client.post('/api/customers',json={'name':'Khách mới','phone':'0900000002'}).status_code,403)
    def test_14_customer_full_crud(self):
        r=self.req('POST','/customers',{'name':'Khách mới','phone':'0900000002'});self.assertEqual(r.status_code,201);cid=r.json()['id']
        self.assertEqual(self.req('GET',f'/customers/{cid}').json()['name'],'Khách mới')
        self.assertEqual(self.req('PUT',f'/customers/{cid}',{'name':'Khách đã sửa','phone':'0900000002'}).json()['name'],'Khách đã sửa')
        self.assertEqual(self.req('DELETE',f'/customers/{cid}').status_code,204)
        self.assertEqual(self.req('GET',f'/customers/{cid}').status_code,404)
    def test_15_duplicate_phone(self):self.assertEqual(self.req('POST','/customers',{'name':'Khách trùng','phone':'0900000001'}).status_code,409)
    def test_16_invalid_fields_and_mass_assignment(self):
        self.assertEqual(self.req('POST','/customers',{'name':'A','phone':'abc'}).status_code,422)
        self.assertEqual(self.req('POST','/customers',{'name':'Khách thử','phone':'0900000002','points':999}).status_code,422)
    def test_17_customer_not_found(self):self.assertEqual(self.req('GET','/customers/999').status_code,404)
    def test_18_product_full_crud(self):
        body={'sku':'TEST-02','name':'Sản phẩm mới','category':'Kiểm thử','price':1000,'stock':3}
        r=self.req('POST','/products',body);self.assertEqual(r.status_code,201);pid=r.json()['id']
        body['price']=2000;self.assertEqual(self.req('PUT',f'/products/{pid}',body).json()['price'],2000)
        self.assertEqual(self.req('GET',f'/products/{pid}').status_code,200)
        self.assertEqual(self.req('DELETE',f'/products/{pid}').status_code,204)
    def test_19_product_invalid_price_stock(self):
        for price,stock in [(0,1),(1,-1),(1.2,1)]:self.assertEqual(self.req('POST','/products',{'sku':'TEST-02','name':'Hàng thử','category':'Kiểm thử','price':price,'stock':stock}).status_code,422)
    def test_20_cashier_cannot_manage_products(self):
        self.cashier();self.assertEqual(self.req('DELETE','/products/1').status_code,403)
    def test_21_checkout_updates_stock_points_ledger(self):
        r=self.order(2);self.assertEqual(r.status_code,201);self.assertEqual(r.json()['total'],200000)
        self.assertEqual(self.req('GET','/products/1').json()['stock'],8)
        c=self.req('GET','/customers/1').json();self.assertEqual((c['points'],c['total_spent']),(20,200000));self.assertEqual(sum(x['delta'] for x in c['ledger']),20)
    def test_22_out_of_stock_rolls_back(self):
        self.assertEqual(self.order(11).status_code,409);self.assertEqual(self.req('GET','/products/1').json()['stock'],10);self.assertEqual(len(self.req('GET','/purchases').json()),0)
    def test_23_multi_item_failure_rolls_back(self):
        with SessionLocal() as db:db.add(Product(sku='TEST-02',name='Hàng hết',category='Thử',price=100,stock=0));db.commit()
        self.assertEqual(self.order(items=[{'product_id':1,'quantity':2},{'product_id':2,'quantity':1}]).status_code,409)
        self.assertEqual(self.req('GET','/products/1').json()['stock'],10)
    def test_24_insufficient_points(self):self.assertEqual(self.order(redeem=1).status_code,409)
    def test_25_redeem_and_earn(self):
        self.order(3);r=self.order(1,20);self.assertEqual((r.json()['total'],r.json()['earned']),(80000,8));self.assertEqual(self.req('GET','/customers/1').json()['points'],18)
    def test_26_redeem_over_twenty_percent(self):
        self.order(3);self.assertEqual(self.order(1,21).status_code,409)
    def test_27_request_replay_is_idempotent(self):
        a=self.order(key='same-request-01');b=self.order(key='same-request-01')
        self.assertEqual(a.json()['id'],b.json()['id']);self.assertEqual(len(self.req('GET','/purchases').json()),1);self.assertEqual(self.req('GET','/products/1').json()['stock'],9)
    def test_28_same_key_changed_body_conflicts(self):
        self.order(key='same-request-02');self.assertEqual(self.order(2,key='same-request-02').status_code,409)
    def test_29_cancel_reverses_stock_points_revenue(self):
        oid=self.order(2).json()['id'];r=self.req('POST',f'/purchases/{oid}/cancel',{'reason':'Kiểm thử hủy đơn'})
        self.assertEqual(r.status_code,200);self.assertEqual(r.json()['status'],'CANCELLED');self.assertEqual(self.req('GET','/products/1').json()['stock'],10)
        c=self.req('GET','/customers/1').json();self.assertEqual((c['points'],c['total_spent']),(0,0));self.assertEqual(sum(x['delta'] for x in c['ledger']),0)
    def test_30_cancel_twice_no_side_effect(self):
        oid=self.order().json()['id'];self.req('POST',f'/purchases/{oid}/cancel',{'reason':'Kiểm thử hủy đơn'});self.assertEqual(self.req('POST',f'/purchases/{oid}/cancel',{'reason':'Kiểm thử hủy đơn'}).status_code,409);self.assertEqual(self.req('GET','/products/1').json()['stock'],10)
    def test_31_cashier_cannot_cancel(self):
        oid=self.order().json()['id'];self.cashier();self.assertEqual(self.req('POST',f'/purchases/{oid}/cancel',{'reason':'Kiểm thử hủy đơn'}).status_code,403)
    def test_32_cannot_delete_customer_with_history(self):
        self.order();self.assertEqual(self.req('DELETE','/customers/1').status_code,409)
    def test_33_cannot_delete_product_with_history(self):
        self.order();self.assertEqual(self.req('DELETE','/products/1').status_code,409)
    def test_34_inactive_customer_blocked(self):
        self.req('PUT','/customers/1',{'name':'Khách kiểm thử','phone':'0900000001','active':False});self.assertEqual(self.order().status_code,409)
    def test_35_inactive_product_blocked(self):
        self.req('PUT','/products/1',{'sku':'TEST-01','name':'Hàng thử','category':'Kiểm thử','price':100000,'stock':10,'active':False});self.assertEqual(self.order().status_code,409)
    def test_36_summary_ignores_cancelled(self):
        a=self.order().json()['id'];self.order(2);self.req('POST',f'/purchases/{a}/cancel',{'reason':'Kiểm thử hủy đơn'});s=self.req('GET','/reports/summary').json();self.assertEqual((s['orders'],s['cancelled'],s['revenue']),(1,1,200000))
    def test_37_csv_formula_protection(self):
        self.req('POST','/customers',{'name':'=1+1','phone':'0900000002'});r=self.req('GET','/reports/customers.csv');self.assertIn("'=1+1",r.text);self.assertTrue(r.content.startswith(b'\xef\xbb\xbf'))
    def test_38_sql_injection_search(self):
        r=self.req('GET',"/customers?search=%27%20OR%201%3D1--");self.assertEqual(r.status_code,200);self.assertEqual(r.json(),[])
    def test_39_security_headers_and_cookie(self):
        r=self.client.get('/');self.assertEqual(r.headers['X-Frame-Options'],'DENY');self.assertIn("script-src 'self'",r.headers['Content-Security-Policy'])
        r=self.client.post('/api/auth/login',json={'username':'admin','password':'Admin!Test2026'});self.assertIn('HttpOnly',r.headers['set-cookie']);self.assertIn('SameSite=strict',r.headers['set-cookie'])
    def test_40_logout_revokes_session(self):
        self.assertEqual(self.req('POST','/auth/logout').status_code,204);self.assertEqual(self.req('GET','/customers').status_code,401)
    def test_41_rate_limit(self):
        attempts.clear()
        for _ in range(10):self.client.post('/api/auth/login',json={'username':'admin','password':'BadPassword123'})
        self.assertEqual(self.client.post('/api/auth/login',json={'username':'admin','password':'BadPassword123'}).status_code,429)
    def test_42_audit_and_cashier_restriction(self):
        self.order();self.assertEqual(self.req('GET','/audit').json()[0]['action'],'CHECKOUT');self.cashier();self.assertEqual(self.req('GET','/audit').status_code,403);self.assertEqual(self.req('GET','/reports/customers.csv').status_code,403)
    def test_43_cancel_spent_points_blocked(self):
        oid=self.order(3).json()['id'];self.order(1,20)
        self.assertEqual(self.req('POST',f'/purchases/{oid}/cancel',{'reason':'Kiểm thử điểm đã dùng'}).status_code,409)
    def test_44_foreign_key_and_check_constraints(self):
        with SessionLocal() as db:
            db.add(Product(sku='BAD',name='Bad',category='Bad',price=1,stock=-1))
            with self.assertRaises(IntegrityError):db.commit()
            db.rollback();db.add(LoyaltyEntry(customer_id=999,purchase_id=999,delta=1,kind='EARN'))
            with self.assertRaises(IntegrityError):db.commit()
    def test_45_two_concurrent_orders_last_item(self):
        with SessionLocal() as db:db.get(Product,1).stock=1;db.commit()
        def buy(i):
            with TestClient(app) as c:
                r=c.post('/api/auth/login',json={'username':'admin','password':'Admin!Test2026'})
                return c.post('/api/purchases',headers={'X-CSRF-Token':r.json()['csrf']},json={'customer_id':1,'items':[{'product_id':1,'quantity':1}],'request_key':f'concurrent-{i}'}).status_code
        with ThreadPoolExecutor(max_workers=2) as pool:statuses=list(pool.map(buy,[1,2]))
        self.assertEqual(sorted(statuses),[201,409]);self.assertEqual(self.req('GET','/products/1').json()['stock'],0);self.assertEqual(len(self.req('GET','/purchases').json()),1)
    def test_46_purchase_bad_shape(self):
        self.assertEqual(self.order(qty=0).status_code,422)
        self.assertEqual(self.order(items=[{'product_id':1,'quantity':1},{'product_id':1,'quantity':1}]).status_code,422)
    def test_47_sessions_store_only_hashes(self):
        from app.models import AuthSession
        with SessionLocal() as db:
            s=db.scalar(select(AuthSession));self.assertEqual(len(s.token_hash),64);self.assertNotEqual(s.token_hash,self.client.cookies.get('mart_session'))
    def test_48_historical_price_immutable(self):
        oid=self.order().json()['id'];self.req('PUT','/products/1',{'sku':'TEST-01','name':'Tên mới','category':'Kiểm thử','price':999999,'stock':9})
        p=self.req('GET',f'/purchases/{oid}').json();self.assertEqual(p['items'][0]['unit_price'],100000);self.assertEqual(p['items'][0]['name'],'Hàng kiểm thử')
