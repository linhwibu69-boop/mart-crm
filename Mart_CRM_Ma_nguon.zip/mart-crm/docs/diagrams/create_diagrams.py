from pathlib import Path
import subprocess, textwrap
D=Path(__file__).resolve().parent
header='''digraph G { graph [bgcolor="white",pad="0.2",ranksep="0.45",nodesep="0.35",dpi=180]; node [fontname="DejaVu Sans",fontsize=11,color="#444444",penwidth=1,shape=box,style="rounded,filled",fillcolor="white",margin="0.16,0.1"]; edge [fontname="DejaVu Sans",fontsize=9,color="#555555",arrowsize=0.7]; '''
def save(name,body):
 p=D/(name+'.dot');p.write_text(header+body+'}',encoding='utf-8')
 for ext in ['png','svg']:subprocess.run(['dot',f'-T{ext}',str(p),'-o',str(D/(name+'.'+ext))],check=True)

def cls(name,fields):
 import html
 rows=''.join('<TR><TD ALIGN="LEFT">'+html.escape(x)+'</TD></TR>' for x in fields)
 return f'{name} [shape=plain,label=<<TABLE BORDER="1" CELLBORDER="0" CELLSPACING="0" CELLPADDING="6"><TR><TD BORDER="1"><B>{name}</B></TD></TR>{rows}</TABLE>>];'
s= 'rankdir=TB; '+cls('Customer',['+ id: Integer PK','+ name: String','+ phone: String UNIQUE','+ points: Integer','+ consent: Boolean','+ active: Boolean'])+cls('Purchase',['+ id: Integer PK','+ customer_id: FK','+ user_id: FK','+ request_key: UNIQUE','+ gross, total: Integer','+ redeemed, earned: Integer','+ status: PAID / CANCELLED'])+cls('Product',['+ id: Integer PK','+ sku: String UNIQUE','+ name: String','+ price: Integer','+ stock: Integer','+ active: Boolean'])+cls('PurchaseItem',['+ purchase_id: FK','+ product_id: FK','+ product_name: String','+ quantity: Integer','+ unit_price: Integer'])+cls('LoyaltyEntry',['+ id: Integer PK','+ customer_id: FK','+ purchase_id: FK','+ delta: Integer','+ kind: String'])+cls('User',['+ id: Integer PK','+ username: UNIQUE','- password_hash: String','+ role: admin / cashier'])+cls('AuthSession',['+ user_id: FK','- token_hash: UNIQUE','- csrf: String','+ expires: Integer'])+cls('AuditLog',['+ user_id: FK','+ action: String','+ entity: String','+ entity_id: Integer'])
s+='''{rank=same;Customer;Purchase;Product;} {rank=same;LoyaltyEntry;PurchaseItem;} {rank=same;AuthSession;User;AuditLog;}
Customer -> Purchase [dir=none,taillabel="1",headlabel="0..*",label="lịch sử mua"];
Purchase -> PurchaseItem [dir=both,arrowtail=diamond,arrowhead=none,taillabel="1",headlabel="1..*"];
Product -> PurchaseItem [dir=none,taillabel="1",headlabel="0..*"];
Customer -> LoyaltyEntry [dir=none,taillabel="1",headlabel="0..*"];
Purchase -> LoyaltyEntry [dir=none,taillabel="1",headlabel="0..*"];
User -> Purchase [dir=none,taillabel="1",headlabel="0..*",label="lập hóa đơn",constraint=false];
User -> AuthSession [dir=none,taillabel="1",headlabel="0..*"];
User -> AuditLog [dir=none,taillabel="1",headlabel="0..*"];
'''
s=s.split('User [shape=plain')[0]+"""{rank=same;Customer;Purchase;Product;} {rank=same;LoyaltyEntry;PurchaseItem;}
Customer -> Purchase [dir=none,taillabel="1",headlabel="0..*",label="lịch sử mua"];
Purchase -> PurchaseItem [dir=both,arrowtail=diamond,arrowhead=none,taillabel="1",headlabel="1..*"];
Product -> PurchaseItem [dir=none,taillabel="1",headlabel="0..*"];
Customer -> LoyaltyEntry [dir=none,taillabel="1",headlabel="0..*"];
Purchase -> LoyaltyEntry [dir=none,taillabel="1",headlabel="0..*"];"""
save('01-class-domain',s)
save('08-class-identity','rankdir=TB;'+cls('User',['+ id: Integer PK','+ username: UNIQUE','- password_hash: String','+ role: admin / cashier'])+cls('AuthSession',['+ user_id: FK','- token_hash: UNIQUE','- csrf: String','+ expires: Integer'])+cls('AuditLog',['+ user_id: FK','+ action, entity: String','+ entity_id: Integer'])+cls('Purchase',['+ user_id: FK'])+'User -> AuthSession [dir=none,taillabel="1",headlabel="0..*"]; User -> AuditLog [dir=none,taillabel="1",headlabel="0..*"];User -> Purchase [dir=none,taillabel="1",headlabel="0..*"];')
s='rankdir=TB;'+cls('CatalogController',['+ create_customer(dto)','+ update_customer(id,dto)','+ delete_customer(id)','+ create_product(dto)'])+cls('PurchaseController',['+ create(dto)','+ cancel(id,dto)'])+cls('CatalogService',['- db: Session','- repo: CatalogRepository','+ save(model,dto,actor,id)','+ remove(model,id,actor)'])+cls('PurchaseService',['- db: Session','- repo: CatalogRepository','+ create(dto,actor)','+ cancel(id,dto,actor)'])+cls('CatalogRepository',['- db: Session','+ get(model,id)','+ customer_spent(id)','+ customers(search,active)','+ products()'])+cls('SQLAlchemySession',['+ add(entity)','+ flush()','+ commit()','+ rollback()'])
s+='''{rank=same;CatalogController;PurchaseController;} {rank=same;CatalogService;PurchaseService;} CatalogController -> CatalogService [style=dashed,label="gọi"];PurchaseController -> PurchaseService [style=dashed,label="gọi"];CatalogService -> CatalogRepository [style=dashed];PurchaseService -> CatalogRepository [style=dashed];CatalogRepository -> SQLAlchemySession [style=dashed];PurchaseService -> SQLAlchemySession [style=dashed,label="transaction"];'''
save('02-class-services',s)

def activity(name,nodes,edges):
 body='rankdir=TB; start [shape=circle,label="",width=0.15,height=0.15,style=filled,fillcolor=black]; end [shape=doublecircle,label="",width=0.17,height=0.17,style=filled,fillcolor=black];'
 for key,label,decision in nodes:
  label='\\n'.join(textwrap.fill(line,width=26 if decision else 34,break_long_words=False).replace('\n','\\n') for line in label.splitlines())
  body+=f'{key} [label="{label}",shape={"diamond" if decision else "box"}'+(',style="filled"' if decision else '')+'];'
 for a,b,label in edges:body+=f'{a} -> {b}'+(f' [label="{label}"]' if label else '')+';'
 save(name,body)
activity('03-activity-login',[
 ('a','Nhập tên đăng nhập và mật khẩu',False),('b','DTO hợp lệ?',True),('c','Giới hạn tần suất cho phép?',True),('d','Tìm User và kiểm tra scrypt',False),('e','Thông tin đúng?',True),('f','Sinh token và CSRF ngẫu nhiên\nLưu hash token, hạn phiên 8 giờ',False),('g','Đặt cookie HttpOnly SameSite Strict\nTrả thông tin tài khoản và CSRF',False),('h','Mở giao diện quản trị',False),('x','Trả lỗi 422 / 429 / 401',False)],
 [('start','a',''),('a','b',''),('b','x','[không]'),('b','c','[có]'),('c','x','[không]'),('c','d','[có]'),('d','e',''),('e','x','[không]'),('e','f','[có]'),('f','g',''),('g','h',''),('h','end',''),('x','end','')])
activity('04-activity-customer',[
 ('a','Nhập tên, điện thoại, email, địa chỉ',False),('b','Phiên và CSRF hợp lệ?',True),('c','DTO hợp lệ?',True),('d','BEGIN IMMEDIATE\nGhi Customer qua ORM',False),('e','Điện thoại duy nhất?',True),('f','Ghi AuditLog cùng transaction',False),('g','COMMIT và trả 201\nTải lại danh sách khách',False),('x','Trả 401 / 403 / 422',False),('y','ROLLBACK và trả 409',False)],
 [('start','a',''),('a','b',''),('b','x','[không]'),('b','c','[có]'),('c','x','[không]'),('c','d','[có]'),('d','e',''),('e','y','[không]'),('e','f','[có]'),('f','g',''),('g','end',''),('x','end',''),('y','end','')])
activity('05-activity-checkout',[
 ('a','Chọn khách, dòng hàng, số điểm đổi',False),('b','Phiên, CSRF và DTO hợp lệ?',True),('c','BEGIN IMMEDIATE\nKiểm tra request_key và request_hash',False),('d','Yêu cầu đã tồn tại?',True),('r','Cùng người và cùng nội dung?',True),('replay','Trả hóa đơn đã tạo\nKhông trừ thêm kho và điểm',False),('e','Khách, sản phẩm hoạt động\nTồn kho và điểm đủ?',True),('f','Tính gross từ giá trong CSDL\nGiảm giá không vượt 20%?',True),('g','Ghi hóa đơn và chi tiết\nTrừ kho, ghi sổ điểm và AuditLog',False),('h','COMMIT và trả 201',False),('x','Trả 401 / 403 / 422',False),('y','ROLLBACK\nTrả 404 / 409',False)],
 [('start','a',''),('a','b',''),('b','x','[không]'),('b','c','[có]'),('c','d',''),('d','r','[có]'),('r','replay','[có]'),('r','y','[không]'),('replay','end',''),('d','e','[chưa]'),('e','y','[không]'),('e','f','[có]'),('f','y','[không]'),('f','g','[có]'),('g','h',''),('h','end',''),('x','end',''),('y','end','')])
activity('06-activity-cancel',[
 ('a','Chọn hóa đơn và nhập lý do hủy',False),('b','Admin, phiên, CSRF và DTO hợp lệ?',True),('c','BEGIN IMMEDIATE\nĐọc hóa đơn và khách hàng',False),('d','Hóa đơn tồn tại và chưa hủy?',True),('e','Điểm hiện tại + điểm đổi\n− điểm tích còn không âm?',True),('f','Hoàn tồn kho và đảo biến động điểm\nGhi CANCEL vào sổ điểm',False),('g','Đặt trạng thái CANCELLED\nLưu lý do và AuditLog',False),('h','COMMIT và trả 200\nGiữ nguyên chi tiết hóa đơn',False),('x','Trả 401 / 403 / 422',False),('y','ROLLBACK và trả 404 / 409',False)],
 [('start','a',''),('a','b',''),('b','x','[không]'),('b','c','[có]'),('c','d',''),('d','y','[không]'),('d','e','[có]'),('e','y','[không]'),('e','f','[có]'),('f','g',''),('g','h',''),('h','end',''),('x','end',''),('y','end','')])
activity('07-activity-delete',[
 ('a','Chọn khách và xác nhận xóa',False),('b','Admin, phiên và CSRF hợp lệ?',True),('c','BEGIN IMMEDIATE\nĐọc hồ sơ khách hàng',False),('d','Hồ sơ tồn tại?',True),('e','Đã phát sinh hóa đơn?',True),('f','ROLLBACK và trả 409\nHướng dẫn ngừng hoạt động hồ sơ',False),('g','Ghi AuditLog và xóa Customer',False),('h','COMMIT và trả 204',False),('x','Trả 401 / 403',False),('y','ROLLBACK và trả 404',False)],
 [('start','a',''),('a','b',''),('b','x','[không]'),('b','c','[có]'),('c','d',''),('d','y','[không]'),('d','e','[có]'),('e','f','[có]'),('e','g','[chưa]'),('g','h',''),('h','end',''),('f','end',''),('x','end',''),('y','end','')])
print('Created 3 class diagrams and 5 activity diagrams')
activity('05-activity-checkout',[
 ('a','Xác thực phiên và CSRF\nKiểm tra DTO, trả lỗi nếu sai',False),
 ('b','BEGIN IMMEDIATE\nĐọc request_key và request_hash',False),
 ('c','Yêu cầu đã có?',True),
 ('r','Nếu cùng người và nội dung\ntrả hóa đơn cũ, ngược lại trả 409',False),
 ('d','Đọc khách hàng và sản phẩm\nKiểm tra hoạt động, kho và điểm',False),
 ('e','Đủ điều kiện mua\nvà đổi điểm?',True),
 ('x','ROLLBACK\nTrả 404 hoặc 409',False),
 ('f','Tính tiền từ giá trong CSDL\nĐiểm đổi không quá 20% tiền hàng',False),
 ('g','Ghi Purchase và PurchaseItem\nTrừ kho, ghi điểm và AuditLog',False),
 ('h','COMMIT và trả 201',False)],
 [('start','a',''),('a','b','[hợp lệ]'),('b','c',''),('c','r','[có]'),('r','end',''),('c','d','[chưa]'),('d','e',''),('e','x','[không]'),('x','end',''),('e','f','[có]'),('f','g',''),('g','h',''),('h','end','')])
